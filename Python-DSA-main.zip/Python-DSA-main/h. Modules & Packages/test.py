from package.maths import addition

from package.subpackages import mul

print(mul(1,3))
print(addition(5,2))

# to get output -> python test.py